<template>
    <Aside></Aside>
</template>

<script>
import Aside from "./components/Aaide"
export default {
    components:{
        Aside
    }
}
</script>

<style>

</style>