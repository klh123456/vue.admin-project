import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)
//写一个方法，name代表文件夹 component代表文件名
const getComponent = (name,component)=> ()=>
   import (`@/views/${name}/${component}.vue`);


const routes = [
  {
    path: '/',
    component:getComponent("Layout","Layout"),
    // children:[{

    // }]
  },
  
  
]

const router = new VueRouter({
  routes
})

export default router
